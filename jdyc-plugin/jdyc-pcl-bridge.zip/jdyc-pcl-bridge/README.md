# JDYC PCL 桥接插件

给 PCL-JDYC 启动器用的 Blessing Skin Server 6 插件，配合皮肤站 OAuth 客户端 PCL-JDYC（客户端 ID 1，回调 http://127.0.0.1:8765/oauth/callback）使用。

## 安装

把 zip 解压后，将 `jdyc-pcl-bridge/` 放进皮肤站的 `plugins/` 目录，在管理后台启用即可。依赖：Blessing Skin Server 6.0.2、Yggdrasil API 插件（已启用）、学生身份认证插件（已启用，用于学生认证判定）。

## 接口（都在 https://mcskin.jdyc.top 下）

- `POST /api/jdyc/oauth/token`（公开，限流 10 次/分钟）：启动器换 token 的代理。只接受 client_id=1 且 redirect_uri=http://127.0.0.1:8765/oauth/callback 的请求，Secret 在服务器端从 oauth_clients 表读，向 Passport 的 /oauth/token 换 token 后原样返回。Secret 不出服务器、不写日志、不进启动器。
- `GET /api/jdyc/student-status`（OAuth，scope User.Read）：返回 `approved`、`status`（approved / pending / rejected / none / not_installed）、被退回时的 `review_note`。判定与学生插件一致：student_check_verifications 里存在该用户且 status=approved 的记录。不返回真实姓名、班级、座位号。
- `POST /api/jdyc/yggdrasil-session`（OAuth，scope User.Read）：入参 `player_pid`（/api/players 返回的 pid）和可选 `clientToken`。先校验学生认证通过、账号未封禁、角色属于该用户，再按 yggdrasil-api 的签发逻辑签 JWT（issuer Yggdrasil-Auth，claim yggt，选中角色加 spr），并按原插件的缓存方式存 token，返回 accessToken、clientToken、availableProfiles、selectedProfile。PCL 按 Auth 方式用 authlib-injector + 这个 token 启动。
- `POST /api/jdyc/upload-texture`（OAuth，scope User.Read + Player.ReadWrite + Closet.ReadWrite）：multipart 表单 `file`（PNG）、`name`、`type`（steve / alex / cape）、`public`（true/false）。逻辑与核心皮肤库上传相同（尺寸校验、PNG 清理、去重、积分、进衣柜），并走 can_upload_texture 过滤器，未通过学生认证的用户在这里同样会被挡住。返回 `tid`，启动器再用核心接口 `PUT /api/players/{pid}/textures` 把这个 tid 设为角色皮肤/披风。

## 启动器侧配合

启动器用 PCL-JDYC 客户端走浏览器授权，本地 127.0.0.1:8765 收 code，PKCE + 本插件换 token；换 token 后先查 student-status，通过才关闭强制弹窗并允许进入；设置页用核心 OAuth API（/api/user、/api/players、/api/closet）显示账号、角色、皮肤预览和快捷换肤/披风，上传走本插件。
