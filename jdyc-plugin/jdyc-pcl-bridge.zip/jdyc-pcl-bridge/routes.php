<?php

declare(strict_types=1);

// 换 token 代理是公开端点：它收的是浏览器刚发回的授权码，
// Secret 在服务器端从 oauth_clients 表查，不经过启动器。
// 其余端点都走 Passport OAuth 鉴权，调用方必须持有有效的 OAuth token。
Route::post('oauth/token', 'JdycController@exchangeToken')
    ->middleware('throttle:10,1');

Route::middleware(['auth:oauth', 'scope:User.Read'])->group(function (): void {
    Route::get('student-status', 'JdycController@studentStatus');
    Route::post('yggdrasil-session', 'JdycController@yggdrasilSession');
});

Route::middleware(['auth:oauth', 'scope:User.Read,Player.ReadWrite,Closet.ReadWrite,Closet.ReadWrtie'])->group(function (): void {
    Route::post('upload-texture', 'JdycController@uploadTexture');
});
