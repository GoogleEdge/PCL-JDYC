<?php

declare(strict_types=1);

namespace GoogleEdge\JdycBridge;

use App\Models\Player;
use App\Models\Texture;
use Blessing\Filter;
use Blessing\Rejection;
use Carbon\CarbonImmutable;
use Illuminate\Contracts\Events\Dispatcher;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Intervention\Image\Facades\Image;
use Lcobucci\JWT;
use Ramsey\Uuid\Uuid;

/**
 * JDYC PCL 桥接。
 *
 * 启动器是公开分发的桌面程序，不能持有 OAuth Secret，
 * 所以换 token 必须在服务器端完成：本插件从 oauth_clients 表
 * 读出 PCL-JDYC 客户端的 Secret，向 Passport 的 /oauth/token
 * 换 token，再把 token 交给启动器。Secret 从不出服务器，
 * 也不写进任何日志和返回体。
 */
class JdycController extends Controller
{
    /** 皮肤站学生认证插件的表（见 blessing_skin_student_check）。 */
    private const STUDENT_TABLE = 'student_check_verifications';

    /** PCL-JDYC 在皮肤站 OAuth 管理里的客户端 ID。 */
    private const PCL_CLIENT_ID = 1;

    /** PCL-JDYC 的回调地址，必须与 OAuth 客户端登记的完全一致。 */
    private const PCL_REDIRECT_URI = 'http://127.0.0.1:8765/oauth/callback';

    // ------------------------------------------------------------------
    // 换 token 代理
    // ------------------------------------------------------------------

    public function exchangeToken(Request $request)
    {
        $data = $request->validate([
            'grant_type' => ['required', Rule::in(['authorization_code', 'refresh_token'])],
            'client_id' => 'required|integer',
            'code' => 'required_if:grant_type,authorization_code',
            'refresh_token' => 'required_if:grant_type,refresh_token',
            'redirect_uri' => 'required_if:grant_type,authorization_code',
            'code_verifier' => 'nullable|string',
        ]);

        if ((int) $data['client_id'] !== self::PCL_CLIENT_ID) {
            return response()->json(['error' => 'invalid_client'], 401);
        }

        if ($data['grant_type'] === 'authorization_code' && $data['redirect_uri'] !== self::PCL_REDIRECT_URI) {
            return response()->json(['error' => 'invalid_redirect_uri'], 400);
        }

        // 只允许登记过的 PCL-JDYC 客户端走这个代理，Secret 从数据库读。
        $client = DB::table('oauth_clients')->where('id', self::PCL_CLIENT_ID)->first();
        if (!$client || empty($client->secret) || $client->redirect !== self::PCL_REDIRECT_URI) {
            return response()->json(['error' => 'invalid_client'], 401);
        }

        $payload = [
            'grant_type' => $data['grant_type'],
            'client_id' => self::PCL_CLIENT_ID,
            'client_secret' => $client->secret,
        ];
        if ($data['grant_type'] === 'authorization_code') {
            $payload['code'] = $data['code'];
            $payload['redirect_uri'] = self::PCL_REDIRECT_URI;
            if (!empty($data['code_verifier'])) {
                $payload['code_verifier'] = $data['code_verifier'];
            }
        } else {
            $payload['refresh_token'] = $data['refresh_token'];
        }

        $response = Http::asForm()->post(url('/oauth/token'), $payload);

        return response()->json($response->json(), $response->status());
    }

    // ------------------------------------------------------------------
    // 学生认证状态
    // ------------------------------------------------------------------

    /**
     * 返回当前 OAuth 用户的学生认证状态。
     * 判定与学生插件 StudentAccess::isApproved 完全一致：
     * student_check_verifications 里存在一条该用户且 status=approved 的记录。
     * 不返回真实姓名、班级、座位号，启动器不需要这些个人信息。
     */
    public function studentStatus()
    {
        $user = Auth::user();
        $status = $this->studentStatusFor($user);

        return response()->json([
            'approved' => $status['approved'],
            'status' => $status['status'],
            'review_note' => $status['status'] === 'rejected' ? $status['review_note'] : null,
        ]);
    }

    private function studentStatusFor($user): array
    {
        if (!$user || !isset($user->uid)) {
            return ['approved' => false, 'status' => 'none', 'review_note' => null];
        }

        if (!Schema::hasTable(self::STUDENT_TABLE)) {
            return ['approved' => false, 'status' => 'not_installed', 'review_note' => null];
        }

        $record = DB::table(self::STUDENT_TABLE)->where('user_id', (int) $user->uid)->first();
        if (!$record) {
            return ['approved' => false, 'status' => 'none', 'review_note' => null];
        }

        return [
            'approved' => $record->status === 'approved',
            'status' => $record->status,
            'review_note' => $record->review_note ?? null,
        ];
    }

    // ------------------------------------------------------------------
    // Yggdrasil 会话签发（复用 yggdrasil-api 的签发逻辑，不用密码）
    // ------------------------------------------------------------------

    public function yggdrasilSession(Request $request)
    {
        $user = Auth::user();
        if (!$user) {
            return response()->json(['error' => 'unauthenticated'], 401);
        }

        // 未通过学生认证的用户不给启动会话，启动器弹窗保持显示。
        $student = $this->studentStatusFor($user);
        if (!$student['approved']) {
            return response()->json([
                'error' => 'student_verification_required',
                'status' => $student['status'],
                'review_note' => $student['review_note'],
            ], 403);
        }

        if ($user->permission == \App\Models\User::BANNED) {
            return response()->json(['error' => 'user_banned'], 403);
        }

        $pid = (int) $request->input('player_pid', 0);
        $player = Player::find($pid);
        if (!$player || (int) $player->uid !== (int) $user->uid) {
            return response()->json(['error' => 'player_not_found'], 404);
        }

        $jwtSecret = config('jwt.secret', '');
        if (!$jwtSecret) {
            return response()->json(['error' => 'yggdrasil_not_configured'], 500);
        }

        $clientToken = $request->input('clientToken', Uuid::uuid4()->getHex()->toString());
        $userUuid = Uuid::uuid5(Uuid::NAMESPACE_DNS, $user->email)->getHex()->toString();

        $jwtConfig = JWT\Configuration::forSymmetricSigner(
            new JWT\Signer\Hmac\Sha256(),
            JWT\Signer\Key\InMemory::plainText($jwtSecret)
        );
        $builder = $jwtConfig->builder();
        $builder->relatedTo($userUuid)
            ->withClaim('yggt', Uuid::uuid4()->getHex()->toString());

        $availableProfiles = [];
        foreach ($user->players as $owned) {
            $availableProfiles[] = [
                'id' => $this->uuidFromName($owned->name),
                'name' => $owned->name,
            ];
        }

        $selected = null;
        foreach ($availableProfiles as $profile) {
            if ($profile['name'] === $player->name) {
                $selected = $profile;
                break;
            }
        }
        if ($selected) {
            $builder->withClaim('spr', $selected['id']);
        }

        $now = CarbonImmutable::now();
        $accessToken = (string) $builder->issuedBy('Yggdrasil-Auth')
            ->expiresAt($now->addSeconds((int) option('ygg_token_expire_1')))
            ->issuedAt($now)
            ->getToken($jwtConfig->signer(), $jwtConfig->signingKey())
            ->toString();

        // 必须存 yggdrasil-api 的 Token 对象本身，不能存 stdClass：
        // sessionserver 校验时会从缓存取出它并调用 isRefreshable()，
        // 存普通对象会在 join/validate 时直接报错。
        if (!class_exists('Yggdrasil\\Models\\Token')) {
            return response()->json(['error' => 'yggdrasil_not_installed'], 500);
        }
        $tokenClass = 'Yggdrasil\\Models\\Token';
        $token = new $tokenClass($clientToken, $accessToken);
        $token->owner = $user->email;
        $token->profileId = $selected ? $selected['id'] : '';
        // 存法与 yggdrasil-api AuthController@storeToken 完全一致，
        // 这样 sessionserver 的 join / hasJoined / validate 才能认这个 token。
        $this->storeYggdrasilToken($token, $user->email);

        return response()->json([
            'accessToken' => $accessToken,
            'clientToken' => $clientToken,
            'availableProfiles' => $availableProfiles,
            'selectedProfile' => $selected,
            'user' => ['id' => $userUuid, 'properties' => []],
        ]);
    }

    /**
     * 与 yggdrasil-api Profile::getUuidFromName 相同的 UUID 分配逻辑：
     * uuid 表里有就用已有的；没有时按站内配置的算法生成并写入。
     * v3 = md5('OfflinePlayer:'+名字) 调整版本号；否则随机 v4。
     */
    private function uuidFromName(string $name): string
    {
        $row = DB::table('uuid')->where('name', $name)->first();
        if ($row) {
            return $row->uuid;
        }

        if (option('ygg_uuid_algorithm') === 'v3') {
            $data = hex2bin(md5('OfflinePlayer:'.$name));
            $data[6] = chr(ord($data[6]) & 0x0F | 0x30);
            $data[8] = chr(ord($data[8]) & 0x3F | 0x80);
            $uuid = bin2hex($data);
        } else {
            $uuid = Uuid::uuid4()->getHex()->toString();
        }

        DB::table('uuid')->insert(['name' => $name, 'uuid' => $uuid]);

        return $uuid;
    }

    private function storeYggdrasilToken($token, string $identification): void
    {
        $timeToFullyExpired = option('ygg_token_expire_2');
        Cache::put("yggdrasil-token-{$token->accessToken}", $token, $timeToFullyExpired);

        $limit = (int) option('ygg_tokens_limit', 10);
        $tokens = Arr::wrap(Cache::get("yggdrasil-id-$identification"));
        if (count($tokens) >= $limit) {
            $expired = array_shift($tokens);
            if ($expired) {
                Cache::forget('yggdrasil-token-'.$expired->accessToken);
            }
        }
        $tokens[] = $token;
        Cache::put("yggdrasil-id-$identification", $tokens);
    }

    // ------------------------------------------------------------------
    // PNG 材质上传（逻辑与核心 SkinlibController@handleUpload 相同，
    // 但用 OAuth 用户身份，且同样走 can_upload_texture 过滤器，
    // 未通过学生认证的用户在这里也会被学生插件挡住）
    // ------------------------------------------------------------------

    public function uploadTexture(Request $request, Filter $filter, Dispatcher $dispatcher)
    {
        $file = $request->file('file');
        if ($file && !$file->isValid()) {
            return response()->json(['message' => 'invalid_file'], 400);
        }

        $data = $request->validate([
            'name' => [
                'required',
                option('texture_name_regexp') ? 'regex:'.option('texture_name_regexp') : 'string',
            ],
            'file' => 'required|mimes:png|max:'.option('max_upload_file_size'),
            'type' => ['required', Rule::in(['steve', 'alex', 'cape'])],
            'public' => 'required|boolean',
        ]);

        $file = $filter->apply('uploaded_texture_file', $file);
        $name = $filter->apply('uploaded_texture_name', $data['name'], [$file]);

        $can = $filter->apply('can_upload_texture', true, [$file, $name]);
        if ($can instanceof Rejection) {
            return response()->json(['message' => $can->getReason()], 403);
        }

        $type = $data['type'];
        $size = getimagesize($file);
        if (!$size) {
            return response()->json(['message' => 'invalid_image'], 400);
        }

        $maxWidth = option('max_texture_width', 8192);
        if ($size[0] > $maxWidth || $size[0] % 64 != 0 || $size[1] % 32 != 0) {
            return response()->json(['message' => 'invalid_texture_size'], 400);
        }
        $ratio = $size[0] / $size[1];
        if ($type === 'cape') {
            if ($ratio != 2) {
                return response()->json(['message' => 'invalid_texture_size'], 400);
            }
        } else {
            if (($ratio != 2 && $ratio != 1) || ($type === 'alex' && $ratio === 2)) {
                return response()->json(['message' => 'invalid_texture_size'], 400);
            }
        }

        $image = Image::make($file);
        $imagick = $image->getCore();
        $imagick->setOption('png:compression-filter', '0');
        $imagick->setOption('png:compression-level', '9');
        $imagick->setOption('png:compression-strategy', '0');
        $imagick->setOption('png:exclude-chunk', 'all');
        $imagick->stripImage();
        $sanitized = $image->encode('png')->getEncoded();

        $hash = hash('sha256', $image->encoded);
        $hash = $filter->apply('uploaded_texture_hash', $hash, [$image]);

        $user = Auth::user();
        $duplicated = Texture::where('hash', $hash)
            ->where(function (Builder $query) use ($user) {
                $query->where('public', true)->orWhere('uploader', $user->uid);
            })
            ->first();
        if ($duplicated) {
            return response()->json(['tid' => $duplicated->tid, 'repeated' => true]);
        }

        $fileSize = (int) ceil(strlen($sanitized) / 1024);
        $isPublic = is_string($data['public']) ? $data['public'] === '1' : (bool) $data['public'];
        $cost = $fileSize * ($isPublic ? option('score_per_storage') : option('private_score_per_storage'));
        $cost += option('score_per_closet_item');
        $cost -= option('score_award_per_texture', 0);
        if ($user->score < $cost) {
            return response()->json(['message' => 'lack_score'], 403);
        }

        $dispatcher->dispatch('texture.uploading', [$image, $name, $hash]);

        $texture = new Texture();
        $texture->name = $name;
        $texture->type = $type;
        $texture->hash = $hash;
        $texture->size = $fileSize;
        $texture->public = $isPublic;
        $texture->uploader = $user->uid;
        $texture->likes = 1;
        $texture->save();

        $disk = Storage::disk('textures');
        if ($disk->missing($hash)) {
            $disk->put($hash, $sanitized);
        }

        $user->score -= $cost;
        $user->closet()->attach($texture->tid, ['item_name' => $name]);
        $user->save();

        $dispatcher->dispatch('texture.uploaded', [$texture, $image]);

        return response()->json(['tid' => $texture->tid]);
    }
}
