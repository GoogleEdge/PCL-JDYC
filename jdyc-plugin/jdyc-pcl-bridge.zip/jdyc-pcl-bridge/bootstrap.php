<?php

declare(strict_types=1);

use App\Services\Hook;

return function (): void {
    Hook::addRoute(function (): void {
        Route::namespace('GoogleEdge\\JdycBridge')
            ->prefix('api/jdyc')
            ->group(__DIR__.'/routes.php');
    });
};
